-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: event
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblcompany`
--

DROP TABLE IF EXISTS `tblcompany`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcompany` (
  `id` int NOT NULL,
  `regno` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `companyname` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `companyemail` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `country` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `companyphone` text NOT NULL,
  `companyaddress` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `companylogo` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'avatar15.jpg',
  `status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '0',
  `creationdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcompany`
--

LOCK TABLES `tblcompany` WRITE;
/*!40000 ALTER TABLE `tblcompany` DISABLE KEYS */;
INSERT INTO `tblcompany` VALUES (1,'REG001','Elite Events','contact@eliteevents.com','USA','+1234567890','123 Main St, New York','logo1.jpg','1','2022-12-31 18:00:00'),(2,'REG002','Royal Celebrations','info@royalcelebrations.com','UK','+2345678901','456 High St, London','logo2.jpg','1','2023-01-01 18:00:00'),(3,'REG003','Dream Makers','contact@dreammakers.com','Canada','+3456789012','789 Queen St, Toronto','logo3.jpg','1','2023-01-02 18:00:00'),(4,'REG004','Perfect Planners','info@perfectplanners.com','Australia','+4567890123','321 King St, Sydney','logo4.jpg','1','2023-01-03 18:00:00'),(5,'REG005','Glamour Events','contact@glamourevents.com','France','+5678901234','654 Rue Paris, Paris','logo5.jpg','1','2023-01-04 18:00:00'),(6,'REG006','Star Celebrations','info@starcelebrations.com','Germany','+6789012345','987 Berlin St, Berlin','logo6.jpg','1','2023-01-05 18:00:00'),(7,'REG007','Golden Moments','contact@goldenmoments.com','Spain','+7890123456','147 Madrid Ave, Madrid','logo7.jpg','1','2023-01-06 18:00:00'),(8,'REG008','Silver Lining Events','info@silverlining.com','Italy','+8901234567','258 Rome Rd, Rome','logo8.jpg','1','2023-01-07 18:00:00'),(9,'REG009','Premier Events','contact@premierevents.com','Japan','+9012345678','369 Tokyo St, Tokyo','logo9.jpg','1','2023-01-08 18:00:00'),(10,'REG010','Luxury Affairs','info@luxuryaffairs.com','Singapore','+0123456789','741 Marina Bay, Singapore','logo10.jpg','1','2023-01-09 18:00:00'),(11,'REG011','Classic Events','contact@classicevents.com','India','+1122334455','852 Mumbai Rd, Mumbai','logo11.jpg','1','2023-01-10 18:00:00'),(12,'REG012','Modern Celebrations','info@moderncelebrations.com','Brazil','+2233445566','963 Rio St, Rio','logo12.jpg','1','2023-01-11 18:00:00'),(13,'REG013','Platinum Events','contact@platinumevents.com','Mexico','+3344556677','159 Mexico City, Mexico','logo13.jpg','1','2023-01-12 18:00:00'),(14,'REG014','Diamond Celebrations','info@diamondcelebrations.com','UAE','+4455667788','267 Dubai Mall, Dubai','logo14.jpg','1','2023-01-13 18:00:00'),(15,'REG015','Crown Events','contact@crownevents.com','Russia','+5566778899','348 Moscow Rd, Moscow','logo15.jpg','1','2023-01-14 18:00:00'),(16,'REG016','Supreme Events','info@supremeevents.com','China','+6677889900','459 Beijing St, Beijing','logo16.jpg','1','2023-01-15 18:00:00'),(17,'REG017','Exclusive Affairs','contact@exclusiveaffairs.com','Malaysia','+7788990011','570 KL Tower, Kuala Lumpur','logo17.jpg','1','2023-01-16 18:00:00'),(18,'REG018','Grand Celebrations','info@grandcelebrations.com','Thailand','+8899001122','681 Bangkok Ave, Bangkok','logo18.jpg','1','2023-01-17 18:00:00'),(19,'REG019','Imperial Events','contact@imperialevents.com','Vietnam','+9900112233','792 Hanoi Rd, Hanoi','logo19.jpg','1','2023-01-18 18:00:00'),(20,'REG020','Majestic Celebrations','info@majesticcelebrations.com','Indonesia','+0011223344','803 Jakarta St, Jakarta','logo20.jpg','1','2023-01-19 18:00:00');
/*!40000 ALTER TABLE `tblcompany` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-22 11:06:57
