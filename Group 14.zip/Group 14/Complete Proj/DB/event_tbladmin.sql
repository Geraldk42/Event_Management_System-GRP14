-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: event
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbladmin`
--

DROP TABLE IF EXISTS `tbladmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbladmin` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Staffid` varchar(255) DEFAULT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `MobileNumber` bigint DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Status` int NOT NULL DEFAULT '1',
  `Photo` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'avatar15.jpg',
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbladmin`
--

LOCK TABLES `tbladmin` WRITE;
/*!40000 ALTER TABLE `tbladmin` DISABLE KEYS */;
INSERT INTO `tbladmin` VALUES (1,'SA001','Super Admin','superadmin','John','Doe',9876543210,'john.doe@events.com',1,'admin1.jpg','0192023a7bbd73250516f069df18b500','2023-01-01 04:00:00'),(2,'SA002','Event Manager','eventmgr','Jane','Smith',9876543211,'jane.smith@events.com',1,'admin2.jpg','d325ffe191a600f562fb59ae52ccbc75','2023-01-02 04:00:00'),(3,'SA003','Operations Head','opshead','Michael','Johnson',9876543212,'michael.j@events.com',1,'admin3.jpg','d5d126684ac9630c107e55b7f0e76ff5','2023-01-03 04:00:00'),(4,'SA004','Finance Manager','finmgr','Sarah','Williams',9876543213,'sarah.w@events.com',1,'admin4.jpg','ddf04a0a99986b0624a38ceea702be76','2023-01-04 04:00:00'),(5,'SA005','Marketing Lead','mktlead','Robert','Brown',9876543214,'robert.b@events.com',1,'admin5.jpg','d84f8fcb02903f2f7909d3296fc751bb','2023-01-05 04:00:00'),(6,'SA006','HR Manager','hrmgr','Emily','Davis',9876543215,'emily.d@events.com',1,'admin6.jpg','0df1f19150ec76698e143f8f35d9c834','2023-01-06 04:00:00'),(7,'SA007','Event Coordinator','coordinator','David','Miller',9876543216,'david.m@events.com',1,'admin7.jpg','4123570adeabe94c748e3bbeb7c883ca','2023-01-07 04:00:00'),(8,'SA008','Booking Manager','bookingmgr','Lisa','Wilson',9876543217,'lisa.w@events.com',1,'admin8.jpg','6209af25efb234ece470ed36709bf79f','2023-01-08 04:00:00'),(9,'SA009','Customer Service','custserv','James','Taylor',9876543218,'james.t@events.com',1,'admin9.jpg','028992d5d5378be53ba0dc1fe4db9204','2023-01-09 04:00:00'),(10,'SA010','Tech Support','techsupp','Emma','Anderson',9876543219,'emma.a@events.com',1,'admin10.jpg','66854f1b110143269dbffdd806fa66eb','2023-01-10 04:00:00'),(11,'SA011','Quality Manager','qualitymgr','William','Thomas',9876543220,'william.t@events.com',1,'admin11.jpg','0ca448201bd3717be6214c9557e573dc','2023-01-11 04:00:00'),(12,'SA012','Logistics Head','logishead','Olivia','Martin',9876543221,'olivia.m@events.com',1,'admin12.jpg','8d6ae58fb304f32fd1205381be8e4e28','2023-01-12 04:00:00'),(13,'SA013','Security Head','sechead','Daniel','Lee',9876543222,'daniel.l@events.com',1,'admin13.jpg','6e4eee8e391a062865ce4f2fddcb115c','2023-01-13 04:00:00'),(14,'SA014','Vendor Manager','vendormgr','Sophia','White',9876543223,'sophia.w@events.com',1,'admin14.jpg','4522b549b4f2a0eeb98946c80b7b3dc5','2023-01-14 04:00:00'),(15,'SA015','Accounts Manager','accmgr','Matthew','Clark',9876543224,'matthew.c@events.com',1,'admin15.jpg','88cb150cb9bf9223ea2db35c9b59449a','2023-01-15 04:00:00'),(16,'SA016','Staff Supervisor','supervisor','Ava','Lewis',9876543225,'ava.l@events.com',1,'admin16.jpg','7ec638b0ce6a360927fd45fbbe5a45f3','2023-01-16 04:00:00'),(17,'SA017','Training Manager','trainmgr','Joseph','Young',9876543226,'joseph.y@events.com',1,'admin17.jpg','02272a83f4df576ec82d69a0eab2418a','2023-01-17 04:00:00'),(18,'SA018','Client Relations','clientrel','Isabella','Hall',9876543227,'isabella.h@events.com',1,'admin18.jpg','2bdfc95a15f4bb7e05a3403a9d908706','2023-01-18 04:00:00'),(19,'SA019','Business Dev','businessdev','Andrew','King',9876543228,'andrew.k@events.com',1,'admin19.jpg','5f089be645b2f2a8e0b1b2e4844f378f','2023-01-19 04:00:00'),(20,'SA020','Operations Exec','opsexec','Mia','Wright',9876543229,'mia.w@events.com',1,'admin20.jpg','e3b6bcb239ba907e2b9c5e5f2c41332e','2023-01-20 04:00:00'),(21,'U003','TestAdmin','testadmin','Test','Admin',9876543210,'testadmin@example.com',1,'avatar15.jpg','482c811da5d5b4bc6d497ffa98491e38','2024-11-21 08:04:41'),(22,'U004','TestAdmin2','testadmin2','Test2','Admin2',9876543220,'testadmin2@example.com',1,'avatar15.jpg','482c811da5d5b4bc6d497ffa98491e38','2024-11-21 08:05:46'),(23,'U004','TestAdmi2','testadmin2','Test2','Admin2',9876543212,'testadmin2@example.com',1,'avatar15.jpg','482c811da5d5b4bc6d497ffa98491e38','2024-11-22 07:20:30');
/*!40000 ALTER TABLE `tbladmin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-22 11:06:57
