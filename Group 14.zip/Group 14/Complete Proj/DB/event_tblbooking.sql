-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: event
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblbooking`
--

DROP TABLE IF EXISTS `tblbooking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblbooking` (
  `ID` int NOT NULL,
  `BookingID` int DEFAULT NULL,
  `ServiceID` int DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `EventDate` varchar(200) DEFAULT NULL,
  `EventStartingtime` varchar(200) DEFAULT NULL,
  `EventEndingtime` varchar(200) DEFAULT NULL,
  `VenueAddress` mediumtext,
  `EventType` varchar(200) DEFAULT NULL,
  `AdditionalInformation` mediumtext,
  `BookingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Remark` varchar(200) DEFAULT NULL,
  `Status` varchar(200) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbooking`
--

LOCK TABLES `tblbooking` WRITE;
/*!40000 ALTER TABLE `tblbooking` DISABLE KEYS */;
INSERT INTO `tblbooking` VALUES (1,123456789,1,'John Smith',9876543210,'john.smith@email.com','2024-01-15','18:00','23:00','123 Wedding Lane, New York','Wedding','Premium decoration with white theme','2023-12-15 04:00:00','Confirmed','Cancelled','2024-11-21 08:42:40'),(2,123456790,2,'Emily Brown',9876543211,'emily.brown@email.com','2024-01-20','12:00','16:00','456 Party Ave, Boston','Birthday Party','Kids birthday party with entertainment','2023-12-16 05:00:00','Deposit paid','Cancelled','2024-11-21 08:42:40'),(3,123456791,3,'Michael Wilson',9876543212,'michael.w@email.com','2024-01-25','19:00','23:00','789 Corporate Blvd, Chicago','Corporate Conference','Annual company meeting','2023-12-17 06:00:00','Pending payment','Cancelled','2024-11-21 08:42:40'),(4,123456792,4,'Sarah Johnson',9876543213,'sarah.j@email.com','2024-02-01','17:00','22:00','321 Engagement St, Miami','Engagement','Romantic setup required','2023-12-18 07:00:00','Confirmed','Cancelled','2024-11-21 08:42:40'),(5,123456793,5,'David Lee',9876543214,'david.lee@email.com','2024-02-05','09:00','18:00','654 Exhibition Rd, Las Vegas','Trade Show','Tech exhibition setup','2023-12-19 08:00:00','Special requirements noted','Cancelled','2024-11-21 08:42:40'),(6,123456794,6,'Lisa Anderson',9876543215,'lisa.a@email.com','2024-02-10','16:00','20:00','987 Fashion Ave, Los Angeles','Fashion Show','Runway and lighting setup','2023-12-20 09:00:00','Technical check pending','Cancelled','2024-11-21 08:42:40'),(7,123456795,7,'Robert Taylor',9876543216,'robert.t@email.com','2024-02-15','18:30','23:30','147 Celebration Rd, Houston','Anniversary','25th anniversary celebration','2023-12-21 10:00:00','Confirmed','Cancelled','2024-11-21 08:42:40'),(8,123456796,8,'Jennifer White',9876543217,'jennifer.w@email.com','2024-02-20','11:00','15:00','258 Community Ctr, Phoenix','Charity','Fundraising event setup','2023-12-22 11:00:00','Venue confirmed','Cancelled','2024-11-21 08:42:40'),(9,123456797,9,'Thomas Harris',9876543218,'thomas.h@email.com','2024-02-25','19:00','23:00','369 Award Ave, Seattle','Award Ceremony','Company awards night','2023-12-23 12:00:00','AV check required','Cancelled','2024-11-21 08:42:40'),(10,123456798,10,'Mary Martin',9876543219,'mary.m@email.com','2024-03-01','10:00','16:00','741 Product Rd, San Francisco','Product Launch','New tech product launch','2023-12-24 13:00:00','Confirmed','Cancelled','2024-11-21 08:42:40'),(11,123456799,11,'James Wilson',9876543220,'james.w@email.com','2024-03-05','14:00','18:00','852 Seminar St, Denver','Seminar','Business leadership seminar','2023-12-25 14:00:00','Speaker confirmed','Cancelled','2024-11-21 08:42:40'),(12,123456800,12,'Patricia Clark',9876543221,'patricia.c@email.com','2024-03-10','17:00','22:00','963 Party Ln, Atlanta','Cocktail','Corporate mixer event','2023-12-26 15:00:00','Menu finalized','Cancelled','2024-11-21 08:42:40'),(13,123456801,13,'George Rodriguez',9876543222,'george.r@email.com','2024-03-15','16:00','20:00','159 College Rd, Boston','College','Graduation ceremony','2023-12-27 16:00:00','Pending final numbers','Cancelled','2024-11-21 08:42:40'),(14,123456802,14,'Elizabeth Lopez',9876543223,'elizabeth.l@email.com','2024-03-20','19:00','23:59','267 Club Ave, Miami','Night Club','New Year party','2023-12-28 17:00:00','Security arranged','Cancelled','2024-11-21 08:42:40'),(15,123456803,15,'Joseph Martinez',9876543224,'joseph.m@email.com','2024-03-25','11:00','15:00','348 Sports Complex, Chicago','Sports Event','Corporate sports day','2023-12-29 04:00:00','Equipment check pending','Cancelled','2024-11-21 08:42:40'),(16,123456804,16,'Sandra Lee',9876543225,'sandra.l@email.com','2024-04-01','18:00','22:00','459 Wedding Plaza, Houston','Pre Engagement','Family gathering','2023-12-30 05:00:00','Confirmed','Cancelled','2024-11-21 08:42:40'),(17,123456805,17,'Kevin Brown',9876543226,'kevin.b@email.com','2024-04-05','09:00','17:00','570 Temple Rd, Phoenix','Religious','Annual religious gathering','2023-12-31 06:00:00','Special arrangements noted','Cancelled','2024-11-21 08:42:40'),(18,123456806,18,'Michelle Turner',9876543227,'michelle.t@email.com','2024-04-10','16:00','21:00','681 Community Hall, Seattle','Social','Community meetup','2024-01-01 07:00:00','Venue setup pending','Cancelled','2024-11-21 08:42:40'),(19,123456807,19,'Daniel King',9876543228,'daniel.k@email.com','2024-04-15','17:00','22:00','792 Sangeet Hall, San Francisco','Sangeet','Pre-wedding celebration','2024-01-02 08:00:00','Confirmed','Cancelled','2024-11-21 08:42:40'),(20,123456808,20,'Rachel Green',9876543229,'rachel.g@email.com','2024-04-20','18:00','23:00','803 Reception Ave, Los Angeles','Post Wedding','Reception party','2024-01-03 09:00:00','Decoration finalized','Cancelled','2024-11-21 08:42:40');
/*!40000 ALTER TABLE `tblbooking` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-22 11:06:57
